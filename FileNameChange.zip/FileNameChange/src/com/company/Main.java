package com.company;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.File;
import java.io.FileFilter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import java.util.List;

public class Main {

    public static void main(String s[])throws IOException {
        JFileChooser chooser = new JFileChooser();
        chooser.setCurrentDirectory(new java.io.File("."));
        chooser.setDialogTitle("choose folder destination");
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setAcceptAllFileFilterUsed(false);

        if (chooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
//            System.out.println("getCurrentDirectory(): " + chooser.getCurrentDirectory());
//            String currentPath = chooser.getSelectedFile().toString();
//            System.out.println("getSelectedFile() : " + currentPath);
            File folder = chooser.getSelectedFile();
            File[] subFolders = folder.listFiles();
            for(File subFolder : subFolders) {
                System.out.println(subFolder.getName());
                // change folder name here
            }

        } else {
            System.out.println("No Selection ");
        }
    }
}
